# Evaluate A News Article with Natural Language Processing

Meaning cloud API: {<https://www.meaningcloud.com/products/sentiment-analysis> }based on the content of the article.

## Build Tools

* HTML
* CSS
* JavaScript
* Node
* Express
* Webpack
* meaning cloud API
* Jest
* Workbox

## Installation

To improve if npm is installed (via Terminal).
node -v
npm -v

1. Go to the project folder and extract the project
cd folder

2. Install the loaders and plugins
npm i -D @babel/core @babel/preset-env babel-loader
npm i -D style-loader node-sass css-loader sass-loader
npm i -D clean-webpack-plugin
npm i -D html-webpack-plugin
npm i -D mini-css-extract-plugin
npm i -D optimize-css-assets-webpack-plugin terser-webpack-plugin

3. Log in for the API Key at meaning cloud.com

Install dotenv package

npm install dotenv

Build a .env file in the root directory and fill in your Key

API_KEY=**************************

 Start the project
npm run build-prod` | Build project
npm start | Run project

 Open the browser on :"<http://localhost:8081>"
